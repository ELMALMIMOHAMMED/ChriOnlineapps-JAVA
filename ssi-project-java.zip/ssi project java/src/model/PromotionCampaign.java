package model;

import java.time.LocalDate;

public class PromotionCampaign {

    private String name;
    private LocalDate startDate;
    private LocalDate endDate;
    private double discount; // percentage

    public PromotionCampaign(String name, LocalDate startDate, LocalDate endDate, double discount) {
        this.name = name;
        this.startDate = startDate;
        this.endDate = endDate;
        this.discount = discount;
    }

    public boolean isActive() {
        LocalDate today = LocalDate.now();
        return (today.isEqual(startDate) || today.isAfter(startDate)) &&
               (today.isEqual(endDate) || today.isBefore(endDate));
    }

    public double applyDiscount(double amount) {
        return amount - (amount * discount);
    }

    public String getName() {
        return name;
    }

    public double getDiscount() {
        return discount;
    }
}