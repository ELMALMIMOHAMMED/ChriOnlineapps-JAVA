package ecommerce.personne5.service;

import java.time.DayOfWeek;
import java.time.LocalDate;

public class PromotionService {

    public double appliquerPromotion(double montant) {

        LocalDate today = LocalDate.now();

        // Black Friday
        if (today.getMonthValue() == 11 && today.getDayOfMonth() == 25) {

            System.out.println("Promotion Black Friday (-30%)");

            return montant * 0.7;
        }

        // Weekend promotion
        DayOfWeek day = today.getDayOfWeek();

        if (day == DayOfWeek.SATURDAY || day == DayOfWeek.SUNDAY) {

            System.out.println("Promotion Weekend (-10%)");

            return montant * 0.9;
        }

        return montant;
    }
}