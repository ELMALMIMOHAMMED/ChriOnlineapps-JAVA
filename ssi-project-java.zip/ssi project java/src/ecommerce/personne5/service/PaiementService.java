package ecommerce.personne5.service;

import ecommerce.personne5.config.AppConfig;
import ecommerce.personne5.config.BusinessRules;
import ecommerce.personne5.model.*;
import ecommerce.personne5.utils.*;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class PaiementService {

    private final List<Paiement> historiquePaiements;
    private final PaiementStats stats;
    private final Random random;

    private final FraudDetectionService fraudDetectionService;
    private final RetryPaymentService retryPaymentService;
    private final WalletService walletService;
    private final AuditService auditService;
    private final PaiementQueueService queueService;

    // BONUS SERVICES
    private final PromotionService promotionService;
    private final FlashSaleService flashSaleService;
    private final LoyaltyService loyaltyService;

    // NEW BONUS
    private final CashbackService cashbackService;
    private final PaymentTimeoutService timeoutService;
    private final PaymentRecommendationService recommendationService;
    private final RiskAnalysisService riskAnalysisService;

    public PaiementService() {

        this.historiquePaiements = new ArrayList<>();
        this.stats = new PaiementStats();
        this.random = new Random();

        this.fraudDetectionService = new FraudDetectionService();
        this.retryPaymentService = new RetryPaymentService();
        this.walletService = new WalletService();
        this.auditService = new AuditService();
        this.queueService = new PaiementQueueService();

        this.promotionService = new PromotionService();
        this.flashSaleService = new FlashSaleService();
        this.loyaltyService = new LoyaltyService();

        this.cashbackService = new CashbackService();
        this.timeoutService = new PaymentTimeoutService();
        this.recommendationService = new PaymentRecommendationService();
        this.riskAnalysisService = new RiskAnalysisService();
    }

    public Paiement simulerPaiement(Commande commande,
                                    TypePaiement typePaiement,
                                    Coupon coupon,
                                    Wallet wallet) {

        LoggerUtil.info("Debut de simulation du paiement...");

        if (commande == null) {
            LoggerUtil.error("Commande invalide");
            return null;
        }

        long startTime = System.currentTimeMillis();

        if (!timeoutService.verifierTimeout(startTime)) {

            LoggerUtil.error("Transaction expiree");

            return null;
        }

        double montantBase = commande.getTotal();

        double fraisLivraison = calculerFraisLivraison(montantBase);

        double reductionCoupon = 0;

        if (coupon != null && coupon.isActif()) {

            reductionCoupon = montantBase * (coupon.getReductionPourcentage() / 100.0);

            LoggerUtil.success("Coupon applique : " + coupon.getCode());
        }

        double montantFinal = montantBase + fraisLivraison - reductionCoupon;

        if (montantFinal < 0) {
            montantFinal = 0;
        }

        // PROMOTION
        montantFinal = promotionService.appliquerPromotion(montantFinal);

        // FLASH SALE
        montantFinal = flashSaleService.appliquerFlashSale(montantFinal);

        LoggerUtil.info("Montant final apres promotions : " + montantFinal);

        // RECOMMENDATION
        System.out.println(recommendationService.recommander(montantFinal));

        // RISK ANALYSIS
        int riskScore = riskAnalysisService.calculerScoreRisque(montantFinal);

        System.out.println("Risk score : " + riskScore);

        boolean transactionSecurisee = PaiementSecurityUtil.verifierTransaction();

        int scoreFraude = fraudDetectionService.calculerScoreFraude(montantFinal);

        StatutPaiement statut;

        boolean succes = random.nextInt(100) < 80;

        if (!succes) {
            succes = retryPaymentService.retryPaiement(AppConfig.MAX_RETRY_PAIEMENT);
        }

        if (succes) {

            statut = StatutPaiement.ACCEPTE;

        } else {

            statut = StatutPaiement.REFUSE;
        }

        Paiement paiement = new Paiement(
                IdGeneratorUtil.genererIdPaiement(),
                montantBase,
                fraisLivraison,
                reductionCoupon,
                montantFinal,
                LocalDateTime.now().toString(),
                statut,
                typePaiement,
                commande.getIdCommande(),
                "Simulation paiement",
                transactionSecurisee,
                TokenUtil.genererToken(),
                scoreFraude
        );

        paiement.traiterPaiement();

        historiquePaiements.add(paiement);

        queueService.ajouterPaiement(paiement);

        sauvegarderPaiementDansFichier(paiement);

        if (statut == StatutPaiement.ACCEPTE) {

            LoggerUtil.success("Paiement accepte");

            NotificationUtil.envoyerNotificationSucces(commande.getIdCommande());

            int points = loyaltyService.calculerPoints(commande);

            loyaltyService.afficherPoints(points);

            cashbackService.afficherCashback(montantFinal);

            auditService.enregistrerAction("CLIENT", "PAIEMENT_ACCEPTE", paiement.getIdPaiement());

        } else {

            LoggerUtil.error("Paiement refuse");

            NotificationUtil.envoyerNotificationEchec(commande.getIdCommande());

            auditService.enregistrerAction("CLIENT", "PAIEMENT_REFUSE", paiement.getIdPaiement());
        }

        mettreAJourStats(paiement);

        return paiement;
    }

    public double calculerFraisLivraison(double montant) {

        if (montant >= BusinessRules.LIVRAISON_GRATUITE_A_PARTIR) {
            return 0;
        }

        return BusinessRules.FRAIS_LIVRAISON_STANDARD;
    }

    public void afficherHistorique() {

        System.out.println("===== HISTORIQUE PAIEMENTS =====");

        for (Paiement p : historiquePaiements) {

            System.out.println(
                    p.getIdPaiement() +
                            " | " +
                            p.getMontantFinal() +
                            " | " +
                            p.getStatut());
        }
    }

    public void afficherDetailsPaiement(Paiement paiement) {

        if (paiement == null) {
            return;
        }

        System.out.println("===== DETAILS =====");

        System.out.println("Paiement : " + paiement.getIdPaiement());
        System.out.println("Montant final : " + paiement.getMontantFinal());
        System.out.println("Statut : " + paiement.getStatut());
    }

    public boolean rembourserPaiement(Paiement paiement, Commande commande) {

        if (paiement == null || commande == null) {
            return false;
        }

        if (paiement.getStatut() != StatutPaiement.ACCEPTE) {

            LoggerUtil.warning("Impossible de rembourser");

            return false;
        }

        paiement.setStatut(StatutPaiement.REMBOURSE);

        commande.setStatut(StatutCommande.REMBOURSEE);

        LoggerUtil.success("Paiement rembourse");

        return true;
    }

    public boolean confirmerPaiement(Paiement paiement, Commande commande) {

        if (paiement == null || commande == null) {
            return false;
        }

        if (paiement.getStatut() == StatutPaiement.ACCEPTE) {

            commande.setStatut(StatutCommande.PAYEE);

            return true;
        }

        return false;
    }

    private void mettreAJourStats(Paiement paiement) {

        stats.incrementerTotalPaiements();

        if (paiement.getStatut() == StatutPaiement.ACCEPTE) {

            stats.incrementerPaiementsAcceptes();

            stats.ajouterChiffreAffaires(paiement.getMontantFinal());

        } else {

            stats.incrementerPaiementsRefuses();
        }
    }

    private void sauvegarderPaiementDansFichier(Paiement paiement) {

        try (PrintWriter writer = new PrintWriter(new FileWriter("paiements.txt", true))) {

            writer.println(
                    paiement.getIdPaiement() +
                            "," +
                            paiement.getMontantFinal() +
                            "," +
                            paiement.getStatut());

        } catch (IOException e) {

            LoggerUtil.error("Erreur sauvegarde paiement");
        }
    }

    public void afficherRecu(Paiement paiement) {

        System.out.println(RecuGenerator.genererRecu(paiement));
    }

    public void afficherStats() {

        System.out.println(stats);
    }
}