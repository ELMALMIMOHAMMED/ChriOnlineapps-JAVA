package ecommerce.personne5.service;

public class PaymentRecommendationService {

    public String recommander(double montant) {

        if (montant < 200) {

            return "WALLET recommandé";

        } else if (montant < 1000) {

            return "CARTE BANCAIRE recommandée";

        } else {

            return "PAIEMENT EN PLUSIEURS FOIS recommandé";
        }
    }
}