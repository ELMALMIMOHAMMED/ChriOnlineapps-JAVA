package ecommerce.personne5.service;

public class PaymentTimeoutService {

    private static final long TIMEOUT = 300000; // 5 minutes

    public boolean verifierTimeout(long debutTransaction) {

        long maintenant = System.currentTimeMillis();

        return (maintenant - debutTransaction) < TIMEOUT;
    }
}