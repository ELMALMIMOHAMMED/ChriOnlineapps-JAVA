package ecommerce.personne5.service;

import ecommerce.personne5.model.AuditLog;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class AuditService {
    private final List<AuditLog> logs = new ArrayList<>();

    public void enregistrerAction(String acteur, String action, String details) {
        AuditLog log = new AuditLog(LocalDateTime.now().toString(), acteur, action, details);
        logs.add(log);
    }

    public void afficherLogs() {
        System.out.println("\n===== AUDIT LOGS =====");
        for (AuditLog log : logs) {
            System.out.println(log);
        }
        System.out.println("======================\n");
    }

    public void sauvegarderLogsFichier() {
        try (PrintWriter writer = new PrintWriter(new FileWriter("audit_logs.txt", true))) {
            for (AuditLog log : logs) {
                writer.println(log);
            }
        } catch (IOException e) {
            System.out.println("Erreur sauvegarde audit logs : " + e.getMessage());
        }
    }
}