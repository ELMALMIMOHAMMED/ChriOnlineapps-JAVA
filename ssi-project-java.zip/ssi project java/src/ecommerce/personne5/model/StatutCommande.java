package ecommerce.personne5.model;

public enum StatutCommande {
    EN_ATTENTE,
    VALIDEE,
    ANNULEE,
    PAYEE,
    REMBOURSEE
}