package ecommerce.personne5.model;

public enum TypePaiement {
    CARTE_BANCAIRE,
    PAYPAL,
    STRIPE,
    A_LA_LIVRAISON,
    WALLET,
    PAIEMENT_2X,
    PAIEMENT_3X
}