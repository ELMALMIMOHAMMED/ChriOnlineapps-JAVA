package ecommerce.personne5.model;

public enum StatutPaiement {
    EN_ATTENTE,
    ACCEPTE,
    REFUSE,
    REMBOURSE
}