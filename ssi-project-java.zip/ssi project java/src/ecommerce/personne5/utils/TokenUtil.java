package ecommerce.personne5.utils;

import java.util.UUID;

public class TokenUtil {
    private TokenUtil() {
    }

    public static String genererToken() {
        return UUID.randomUUID().toString();
    }
}