package ecommerce.personne5.utils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class LoggerUtil {
    private static final DateTimeFormatter FORMATTER =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private LoggerUtil() {
    }

    private static String now() {
        return LocalDateTime.now().format(FORMATTER);
    }

    public static void info(String message) {
        System.out.println("[" + now() + "] [INFO] " + message);
    }

    public static void success(String message) {
        System.out.println("[" + now() + "] [SUCCESS] " + message);
    }

    public static void warning(String message) {
        System.out.println("[" + now() + "] [WARNING] " + message);
    }

    public static void error(String message) {
        System.out.println("[" + now() + "] [ERROR] " + message);
    }
}